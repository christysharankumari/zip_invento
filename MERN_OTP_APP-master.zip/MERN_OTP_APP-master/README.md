# MERN_OTP_APP
 Complete MERN Stack application with OTP Verification, JWT Token, Authentication, Reset Password
